export default {

  //BASE_URL: 'http://localhost:3000',
  //BASE_URL: 'https://t65-locator.herokuapp.com',
  BASE_URL: 'https://api.t-65locator.com',

};